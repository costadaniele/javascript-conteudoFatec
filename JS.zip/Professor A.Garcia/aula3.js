//ref seraá o mesmo que this
//1) AO CLICAR EM UMA TAG DIV, FAÇA COM QUE SUA
//COR-DE-FUNDO FIQUE AMARELA

function exercicio1(div){
	div.style.backgroundColor = "yellow";
}

//2) AO CLICAR EM UM BOTAO, FAÇA COM QUE UM
//ELEMENTO COM CLASSE classe2 TENHA COR DE FONTE AZUL

function exercicio2(){
	var cl2 = document.querySelector(".classe2");
	cl2.style.color = "#00f";
}

//3) AO CLICAR UM BOTAO DE id b1, MUDE SEU CONTEUDO 
//PARA "CLICADO"

function exercicio3(btn){
	btn.innerHTML = "CLICADO";
}

//4) CRIE UM ELEMENTO P DESSA FORMA:
//<p onclick="clicar(this)">0</p>
//IMPLEMENTE A FUNÇÃO CLICAR QUE INCREMENTA O CONTADOR,
//OU SEJA, APÓS O CLIQUE DEVEREMOS TER
//<p onclick="clicar(this)">1</p>
function clicar(p){
	p.innerHTML = parseInt(p.innerHTML) + 1
}



function sumir(ref){
	ref.style.display = "none";
}

function exe2(){
	var div = document.querySelector("#d1");
	div.style.backgroundColor = "blue";
	div.style.color = "white";
	div.style.display = "none";
}

function exe3(){
	var div2 = document.querySelector(".classe");
	div2.style.backgroundColor = "yellow";
}

function inspecionar(){
	var p = document.getElementById("d1");
	aux = ""
	for (k in p){
		aux += (k + " => " + p[k] + "<br>");
	}
	document.write(aux);
}

function exe1(){
	//document EH O representante do DOM da pagina
	//corrente.
	var p = document.getElementById("p1");
	//MOSTRA O CONTEUDO INTERNO DE p 
	//COMO String.
	alert(p.innerHTML);
}