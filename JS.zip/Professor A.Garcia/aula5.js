function montarTab(){
	var objeto = reqBD();
	var tabela = document.createElement("table");
	var thead = document.createElement("thead");
	var tr = document.createElement("tr");
	var thNome = document.createElement("th");
	var thId = document.createElement("th");
	var thLc = document.createElement("th");
	thNome.innerHTML = "NOME";
	thId.innerHTML = "IDADE";
	thLc.innerHTML = "LOCAL";
	var tBody = document.createElement("tbody");
	for(let i=0; i < objeto.data.length;i++){
		var trB = document.createElement("tr");
		var tdN = document.createElement("td");
		var tdI = document.createElement("td");
		var tdL = document.createElement("td");
		tdN.innerHTML = objeto.data[i].nome;
		tdI.innerHTML = objeto.data[i].idade;
		tdL.innerHTML = objeto.data[i].local;
		trB.appendChild(tdN);
		trB.appendChild(tdI);
		trB.appendChild(tdL);
		tBody.appendChild(trB);
	}
	tr.appendChild(thNome);
	tr.appendChild(thId);
	tr.appendChild(thLc);
	thead.appendChild(tr);
	tabela.appendChild(thead);
	tabela.appendChild(tBody);
	document.body.appendChild(tabela);
}

function reqBD(){
	return {
		data:[{nome:"KAREN",idade:29,local:"SANTOS"}
			 ,{nome:"MATHEUS",idade:31,local:"SANTOS"}
			 ,{nome:"SAMUEL",idade:21,local:"SANTOS"}
			 ,{nome:"MARTA",idade:20,local:"SV"}
			 ,{nome:"ANNNA JULIA",idade:18,local:"GJA"}
			 ]
		};
}

function montar(){
	montaUl(["PHP","HASKELL","JULIA","PYTHON",
	 "RUBY","JS","LUA","JAVA","COBOL","C#",
	 "C++","C","FORTRAN","NODE.JS","ASSEMBLY"]);
}

function montaUl(lista){
	var ul = document.createElement("ul");
	for(let i=0; i < lista.length; i++){
		var li = document.createElement("li");
		li.innerHTML = lista[i];
		ul.appendChild(li);
	}
	document.body.appendChild(ul);
}

function montarPag(){
	var div1 = document.createElement("div");
	var div2 = document.createElement("div");
	div1.appendChild(div2);
	div2.innerHTML = "CRIADO PELO JS";
	div2.style.backgroundColor = "red";
	document.body.appendChild(div1);
}