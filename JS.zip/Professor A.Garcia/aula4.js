function ex3(){
	var lis = document.querySelectorAll("li");
	for(var i=0; i<lis.length;i++){
		if(i % 2 == 0){
			lis[i].innerHTML = "OK";
		}
	}
}

function ex2(){
	var lis = document.querySelectorAll("p, .classe");
	for(var i=0; i<lis.length;i++){
		lis[i].style.display = "none";
	}
}

function pintarA(caixa){
	caixa.style.backgroundColor = "yellow";
}

//SEM o this NO HTML, TEREMOS QUE FAZER BUSCA
function validar(){
	var digitado = document.forms.form2.texto.value;
	var caixa = document.querySelector("#texto");
	if(digitado == ""){
		caixa.style.backgroundColor = "red";
	}else{
		caixa.style.backgroundColor = "white";
	}
}

function teste(){
	//querySelector: OBTEM UM ELEMENTO
	//querySelectorAll: TODOS OS ELEMENTOS
	var lis = document.querySelectorAll("ul> li");
	for(var i=0; i<lis.length;i++){
		lis[i].style.backgroundColor = "yellow";
	}
}

function teste2(){
	var lis = document.querySelectorAll("p, div");
	for(var i=0; i<lis.length;i++){
		lis[i].style.backgroundColor = "#f00";
	}
}

function teste3(){
	var lis = document.querySelectorAll(".classe");
	for(var i=0; i<lis.length;i++){
		lis[i].style.backgroundColor = "#0f0";
	}
}

function somar(){
	var n1 = parseInt(document.forms.form1.n1.value);
	var n2 = parseInt(document.forms.form1.n2.value);
	var div = document.getElementById("resultado");
	div.innerHTML = n1 + n2;
	div.style.backgroundColor = "yellow";
}






