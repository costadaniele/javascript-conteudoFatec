//[{nome:"WESKLEY",p1:6,p2:6.5},
// {nome:"MARTA",p1:5,p2:7},
// {nome:"JEFFERSON",p1:2,p2:9},
// {nome:"REBECA",p1:5.5,p2:1}]
function mediaSala(vetAlu){
	//POIS, OS OBJETOS ESTAO DISPOSTOS EM UMA LISTA
	var media = 0;
	for(let i=0; i < vetAlu.length; i++){
		var md = 0.5*(vetAlu[i].p1 + vetAlu[i].p2);
		document.write("Nome: " + vetAlu[i].nome 
			+ "<br>");
		media = media+md;
	}
	document.write("MEDIA DA SALA: " 
			+ (media/vetAlu.length));
}

//Essa função recebe objetos da forma 
//{nome:"FULANO",p1:6.0,p2:6.5}
function calcularNota(obj){
	document.write(obj.nome + "<br>");
	var media = 0.5*(obj.p1 + obj.p2);
	document.write(media);
}

function exemploObjeto(obj){
	for(let indice in obj){
		document.write(" Indice: " + indice + 
			" Valor: " + obj[indice] + "<br>");
	}
}