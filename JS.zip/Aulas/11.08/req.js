$(criarEvento);

function criarEvento() {
	$("button").click(function() {
		sendReq("https://www.uol.com.br/");
	});
}

function rasparPagina(documento) {
	//alert(documento); //-> para ver se funcionou
	/*var divs = documento.querySelectorAll(".description-noticia, .description-portal");
	
	divs.forEach(function(div) {
		var divNova = document.createElement("div");
		divNova.innerHTML = div.childNodes[3].innerHTML;
		document.body.appendChild(divNova);
	});*/
	
	var ps = documento.querySelectorAll(".color2");
	ps.forEach(function(p) {
		var divNova = document.createElement("div");
		divNova.innerHTML = p.innerHTML;
		document.body.appendChild(divNova);
	});
}

function sendReq(url) {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			//var objResp = JSON.parse(this.responseText);
			//rasparPagina(objResp);
			
			var parser = new DOMParser();
			var documento = parser.parseFromString(this.responseText, "text/html");
			rasparPagina(documento);
		}
	};		
	//para passar cors
	//https://cors-anywhere.herokuapp.com/
	//xhttp.open("GET", "https://fatecrl.edu.br/", true);
	xhttp.open("GET", "https://cors-anywhere.herokuapp.com/" + url, true);
	xhttp.send();
}