function montarPag() {
	var div1 = document.createElement("div");
	var div2 = document.createElement("div");
	div1.appendChild(div2);
	div2.innerHTML = "CRIADO PELO JS";
	div2.style.backgroundColor = "red";
	document.body.appendChild(div1);
}

function montar() {
	montarUl(["PHP", "HASKELL", "JULIA", "PYTHON", "RUBY", "JS", "LUA", "JAVA", "COBOL", "C#", "C++", "C", "FORTRAN", "NODE.JS", "ASSEMBLY"])
}

function montarUl(lista) {
	var ul = document.createElement("ul");
	for(var i = 0; i < lista.length; i++) {
		var li = document.createElement("li");
		li.innerHTML = lista[i];
		ul.appendChild(li);
	}
	document.body.appendChild(ul);
}

function reqBD(){
	return {
		data: [
			{nome: "KAREN", idade: 29, local: "SANTOS"},
			{nome: "MATHEUS", idade: 31, local: "SANTOS"},
			{nome: "SAMUEL", idade: 21, local: "SANTOS"},
			{nome: "MARTA", idade: 20, local: "SV"},
			{nome: "ANNA JULIA", idade: 18, local: "GJA"}
		]
	}
}

function montarTab() {
	var obj = reqBD();
	var tabela = document.createElement("table");
	var thead = document.createElement("thead");
	var tr = document.createElement("tr");
	var thNome = document.createElement("th");
	var thId = document.createElement("th");
	var thLc = document.createElement("th");
	thNome.innerHTML = "NOME";
	thId.innerHTML = "IDADE";
	thLc.innerHTML = "LOCAL";
	var tbody = document.createElement("tbody");
	for (let i=0; i <obj.data.length; i++) {
		var trB = document.createElement("tr");
		var tdN = document.createElement("td");
		var tdI = document.createElement("td");
		var tdL = document.createElement("td");
		tdN.innerHTML = obj.data[i].nome;
		tdI.innerHTML = obj.data[i].idade;
		tdL.innerHTML = obj.data[i].local;
		trB.appendChild(tdN);
		trB.appendChild(tdI);
		trB.appendChild(tdL);
		tbody.appendChild(trB);
	}
	
	tr.appendChild(thNome);
	tr.appendChild(thId);
	tr.appendChild(thLc);
	thead.appendChild(tr);
	tabela.appendChild(thead);
	tabela.appendChild(tbody);
	document.body.appendChild(tabela);
}

function teste() {
	var div = document.querySelector("#d1");
	var h1 = document.createElement("h1");
	h1.innerHTML = "TROCADO";
	div.parentNode.replaceChild(h1,div);
}

//se quiser adicionar de novo, só funcionaria dentro da mesma função
function remover() {
	var div = document.querySelector("#d1");
	div.parentNode.removeChild(div);
}

function inserirOutro() {
	var div3 = document.querySelector("#d3");
	var div = document.createElement("div");
	div.innerHTML = "INSERIDO";
	//div3 EH A REFERENCIA PARA INSERIR
	//O parentNode LOCALIZA O NO PAI PARA PODER EXECUTAR OPERACOES NO CRUD DO DOM
	div3.parentNode.insertBefore(div, div3);
}

function inserirDepois() {
	var div1 = document.querySelector("#d1");
	var novo = document.createElement("div");
	novo.innerHTML = "INSERIDO";
	div1.parentNode.insertBefore(novo, div1.nextSibling);
}

//1) MONTE UMA UL CONTENDO AS LI'S 
//<ul>
//	<li>0</li>
//	<li>2</li>
//	<li>4</li>
//	...
//	<li>1000</li>
//</ul>
function monteUlPar() {
	var ul = document.createElement("ul");
	for (var i = 0; i < 1001; i += 2) {
		var li = document.createElement("li");
		li.innerHTML = i;
		ul.appendChild(li);
	}
	document.body.appendChild(ul);
}

//2) SUBSTITUA TODOS OS ELEMENTOS CONTENDO A CLASSE classe1 POR UM ELEMENTO DIV CONTENDO A STRING "OK".
function subsClasse() {
	var elementos = document.querySelectorAll(".classe1");
	for (var i = 0; i < elementos.length; i++) {
		var div = document.createElement("div");
		div.innerHTML = "OK";
		elementos[i].parentNode.replaceChild(div,elementos[i]);
	}
}