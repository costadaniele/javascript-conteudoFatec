function teste() {
	//querySelector: OBTEM UM ELEMENTO
	//querySelectorAll: OBTEM TODOS OS ELEMENTOS
	var lis = document.querySelectorAll("ul > li");
	
	/*var aux = "";
	for (i in lis) {
		aux = aux + i + " => " + lis[i] + "<br>"
	}
	document.write(aux);*/
	
	for (var i = 0; i < lis.length; i++) {
		lis[i].style.backgroundColor = "#ff0";
	}
}

function teste2() {
	var lis = document.querySelectorAll("p, div");
	
	for (var i = 0; i<lis.length; i++) {
		lis[i].style.backgroundColor = "#f00";
	}
}

function teste3() {
	var lis = document.querySelectorAll(".classe");
	
	for (var i = 0; i<lis.length; i++) {
		lis[i].style.backgroundColor = "#0f0";
	}
}

function somar() {
	var n1 = parseInt(document.forms.form1.n1.value);
	var n2 = parseInt(document.forms.form1.n2.value);
	var div = document.getElementById("resultado");
	div.innerHTML = n1 + n2;
	div.style.backgroundColor = "yellow";
}

//1) AO SAIR DE UMA CAIXA DE TEXTO, SE ELA ESTIVER VAZIA PINTE DE VERMELHO, CASO CONTRARIO DEIXE-A BRANCA. NO FOCO, PINTE-A DE AMARELO
function exe1(ref) {
	if (ref.value == "") {
		ref.style.backgroundColor = "#f00";
	}
	else {
		ref.style.backgroundColor = "#fff";
	}
}

function exe1focus(ref) {
	ref.style.backgroundColor = "#ff0";
}

//2) FACA COM QUE TODAS AS DIVS E OS ELEMENTOS DE CLASSE .classe SUMAM
function exe2() {
	var elems = document.querySelectorAll("div, .classe");
	for (var i = 0; i < elems.length; i++) {
		elems[i].style.display = "none";
	}
}

//3) MUDE O CONTEUDO DAS LI'S DE INDICE PAR PARA "OK".
function exe3() {
	var lis = document.querySelectorAll("ul > li");
	for (var i = 0; i < lis.length; i++) {
		if (i % 2 == 0) {
			lis[i].innerHTML = "OK";
		}
	}
}
