function exe1() {
	//DOM - Document Object Model
	//document eh o representante do DOM da pagina corrente. 
	var p = document.getElementById("p1");
	//MOSTRA O CONTEUDO INTERNO DE p COMO String.
	alert(p.innerHTML);
}

function inspecionar() {
	var p = document.getElementById("teste");
	aux = "";
	for (k in p) {
		aux += (k + " => " + p[k] + "<br>");
	}
	document.write(aux);
}

function exe2() {
	var div = document.querySelector("#d1");
	div.style.backgroundColor = "blue";
	div.style.color = "white";
	//div.style.visibility = "hidden";
	div.style.display = "none";
}

function exe3() {
	var div2 = document.querySelector(".classe");
	div2.style.backgroundColor = "yellow";
}

//ref sera o mesmo que o 'this'
function sumir(ref) {
	ref.style.display = "none";
}

//1) AO CLICAR EM UMA TAG DIV, FAÇA COM QUE SUA COR-DE-FUNDO FIQUE AMARELA 
function ex1(ref) {
	ref.style.backgroundColor = "yellow";
}

//2) AO CLICAR EM UM BOTAO, FAÇA COM QUE UM ELEMENTO COM CLASSE classe2 TENHA COR DE FONTE AZUL
function ex2() {
	var element = document.querySelector(".classe2");
	element.style.color = "blue";
}

//3) AO CLICAR UM BOTAO DE id b1, MUDE SEU CONTEUDO PARA "CLICADO"
function ex3(btn) {
	//var btn = document.querySelector("#b1");
	btn.innerText = "CLICADO";
}

//4) CRIE UM ELEMENTO P DESSA FORMA:
//<p onclick="clicar(this)">0</p>
//IMPLEMENTE A FUNÇÃO CLICAR QUE INCREMENTA O CONTADOR, OU SEJA, APÓS O CLIQUE DEVEREMOS TER 
//<p onclick="clicar(this)">1</p>

function clicar(ref) {
	//let contador = parseInt(ref.innerText);
	//contador = contador + 1;
	//ref.innerText = contador;
	
	ref.innerText = parseInt(ref.innerText) + 1;
}