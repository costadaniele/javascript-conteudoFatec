//exercicio 1
//a
function mediaEscritorio(vetProdutos){
	var media = 0;
	for(let i=0; i < vetProdutos.length; i++){
		if(vetProdutos[i].tipo=="Escritorio"){
			var md = vetProdutos[i].preco + vetProdutos[i].preco;
			document.write("Nome: " + vetProdutos[i].nome + "<br>");
			media = media+md;
		}
	}
	document.write("Media de preços dos produtos de escritório: "+(media/vetProdutos.length));
}
//b
function mediaLivros(vetProdutos){
	var media = 0;
	for(let i=0; i < vetProdutos.length; i++){
		if(vetProdutos[i].tipo=="Livro"){
			var md = vetProdutos[i].preco + vetProdutos[i].preco;
			document.write("Nome: " + vetProdutos[i].nome + "<br>");
			media = media+md;
		}
	}
	document.write("Media de preços dos produtos livros: "+(media/vetProdutos.length));
}

/*	[{nome: "Wesley",p1:6,p2: 6.5},
	 {nome: "Marta",p1:5,p2: 7},
	 {nome: "Jefferson",p1:2,p2: 9}
	 {nome: "Rebeca",p1:5.5,p2: 1}],
*/ 
function mediaSala(vetAlunos){
//Pois, os objetos estão dispostos em uma lista
	var media = 0;
	for(let i=0; i < vetAlunos.length; i++){
		var md = 0.5*(vetAlunos[i].p1 + vetAlunos[i].p2);
		document.write("Nome: " + vetAlunos[i].nome + "<br>");
		media = media+md;
	}
	document.write("Media da sala: "+(media/vetAlunos.length));
}

//essa função recebe objetos da forma {nome:"fulano", p1:6.0,p2:6.5}
//obs: indice *string* pode não ter aspas!
function calculaNota(obj){
	document.write(obj.nome + "<br>");
	var media = 0.5*(obj.p1 + obj.p2);
	document.write(media);
}

function exemploObjeto(obj){
	for(let indice in obj){
		document.write("Inidice: "+indice+" Valor: "+obj[indice]+"<br>"); //escreve na pagina 
	}
}